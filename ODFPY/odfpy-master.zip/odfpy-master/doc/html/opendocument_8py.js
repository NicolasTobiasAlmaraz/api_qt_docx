var opendocument_8py =
[
    [ "OpaqueObject", "classodf_1_1opendocument_1_1OpaqueObject.html", "classodf_1_1opendocument_1_1OpaqueObject" ],
    [ "OpenDocument", "classodf_1_1opendocument_1_1OpenDocument.html", "classodf_1_1opendocument_1_1OpenDocument" ],
    [ "__detectmimetype", "opendocument_8py.html#a15bc2b6008b8d64ff1047dda751b7ddd", null ],
    [ "__fixXmlPart", "opendocument_8py.html#a329e7f7b2fb739050535cf2425e526b8", null ],
    [ "__loadxmlparts", "opendocument_8py.html#acb64b15fe00e69ef79a7c9f4adaf3a6c", null ],
    [ "load", "opendocument_8py.html#a5f91a599e953a7b3d3cd07ad3a696467", null ],
    [ "OpenDocumentChart", "opendocument_8py.html#a6a86bb2e0369feaea53b7c05290b2392", null ],
    [ "OpenDocumentDrawing", "opendocument_8py.html#a5ff2aeb89ca9dfbae829ee5853c7b3e2", null ],
    [ "OpenDocumentImage", "opendocument_8py.html#a3f866df98a777ed31da478c6406d22db", null ],
    [ "OpenDocumentPresentation", "opendocument_8py.html#a8a56383489ab849a51711a04de3f0f63", null ],
    [ "OpenDocumentSpreadsheet", "opendocument_8py.html#a6e2d5bd6da597f4b19f6b285d3802d0d", null ],
    [ "OpenDocumentText", "opendocument_8py.html#aa484e380b454031a93c5da214fab392d", null ],
    [ "OpenDocumentTextMaster", "opendocument_8py.html#af6d010acf6dd4ad33f05b48ce036a208", null ],
    [ "__doc__", "opendocument_8py.html#aef5700f9b878becf7cd993c97584dfee", null ],
    [ "__version__", "opendocument_8py.html#a7ae7b9f7ff753deece3ec6f05a9104ee", null ],
    [ "_XMLPROLOGUE", "opendocument_8py.html#a2598e2e2f5849be1876f9a585f8359dd", null ],
    [ "IS_FILENAME", "opendocument_8py.html#a16a01c597acdbd785c45dc2c8abf6e99", null ],
    [ "IS_IMAGE", "opendocument_8py.html#abdff0b1ae362b65dc635c8e3e74e36cf", null ],
    [ "odmimetypes", "opendocument_8py.html#a5b88ff682371ff9d1cd3d545484e3bfb", null ],
    [ "unicode", "opendocument_8py.html#a35331d671c8f271f0722c22d783ad205", null ],
    [ "UNIXPERMS", "opendocument_8py.html#a8302c421f86687ff0d9f2aca113fd769", null ]
];