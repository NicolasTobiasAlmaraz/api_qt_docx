var meta_8py =
[
    [ "AutoReload", "meta_8py.html#a56f8e703d81c98e516a4964b2381b869", null ],
    [ "CreationDate", "meta_8py.html#a8030344c0edaa27ab1176185dd0144b2", null ],
    [ "DateString", "meta_8py.html#a567835aab7fba93aa9ce9f659fe20e12", null ],
    [ "DocumentStatistic", "meta_8py.html#a3e9b0f205c9211c3c31452aeca178a08", null ],
    [ "EditingCycles", "meta_8py.html#a782529060de4047c0337ad45a927af74", null ],
    [ "EditingDuration", "meta_8py.html#aef8041b653eb35c475a9d5a00d685dab", null ],
    [ "Generator", "meta_8py.html#af358679847dc4f8640f812b78207eac5", null ],
    [ "HyperlinkBehaviour", "meta_8py.html#ae013d09a62e1a8a664262af49719bc53", null ],
    [ "InitialCreator", "meta_8py.html#a734ee7748a850249d7aa80f8b240bfd6", null ],
    [ "Keyword", "meta_8py.html#a49e6c8de501570010e6361810100ae31", null ],
    [ "PrintDate", "meta_8py.html#a47ca1c2ae0f21de9edb7936f2d637924", null ],
    [ "PrintedBy", "meta_8py.html#a1c2b90d3c21ff51af4db4221f53aff70", null ],
    [ "Template", "meta_8py.html#a2315ca939af7c164b441e1ef3def6530", null ],
    [ "UserDefined", "meta_8py.html#a54f5d4628158f4535d6d80212213b6df", null ]
];