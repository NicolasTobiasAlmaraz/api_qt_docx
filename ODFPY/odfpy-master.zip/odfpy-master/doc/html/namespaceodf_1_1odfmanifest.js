var namespaceodf_1_1odfmanifest =
[
    [ "ODFManifestHandler", "classodf_1_1odfmanifest_1_1ODFManifestHandler.html", "classodf_1_1odfmanifest_1_1ODFManifestHandler" ]
];