var svg_8py =
[
    [ "DefinitionSrc", "svg_8py.html#a60e8b50798b894b3440d0ed83bc1c0f6", null ],
    [ "Desc", "svg_8py.html#a012bc99f9022007746481d52783a66cf", null ],
    [ "FontFaceFormat", "svg_8py.html#a885fe209222fd221daae687d13a90192", null ],
    [ "FontFaceName", "svg_8py.html#af5a163223345646472a47b2c37ddfde5", null ],
    [ "FontFaceSrc", "svg_8py.html#ad27dca51de43c731175df09185bcc0be", null ],
    [ "FontFaceUri", "svg_8py.html#aa1769d4f9c290930f551c61d4f3a659f", null ],
    [ "Lineargradient", "svg_8py.html#aad55be3da8e1ec9d65e99c60489092b0", null ],
    [ "Radialgradient", "svg_8py.html#a207eb01363b7981e890942fbd716d237", null ],
    [ "Stop", "svg_8py.html#ab53e9a751ec2f745c59d2d7b0ccf594a", null ],
    [ "Title", "svg_8py.html#a98ec755606b3c038d6ce1b9db9be31ac", null ]
];