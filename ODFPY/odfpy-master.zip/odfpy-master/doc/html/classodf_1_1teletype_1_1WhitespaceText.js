var classodf_1_1teletype_1_1WhitespaceText =
[
    [ "__init__", "classodf_1_1teletype_1_1WhitespaceText.html#aa97a5050c9c37f9b30ebd7c4311501f9", null ],
    [ "addTextToElement", "classodf_1_1teletype_1_1WhitespaceText.html#a286423383ac7f720a7043de4ea89be12", null ],
    [ "spaceCount", "classodf_1_1teletype_1_1WhitespaceText.html#a3917a28f107445a8c7284a466e9d498b", null ],
    [ "textBuffer", "classodf_1_1teletype_1_1WhitespaceText.html#acbf9abb2ff5e2abe625a158e09566571", null ]
];