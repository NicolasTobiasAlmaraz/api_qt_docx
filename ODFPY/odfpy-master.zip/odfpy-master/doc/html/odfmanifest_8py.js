var odfmanifest_8py =
[
    [ "ODFManifestHandler", "classodf_1_1odfmanifest_1_1ODFManifestHandler.html", "classodf_1_1odfmanifest_1_1ODFManifestHandler" ],
    [ "manifestlist", "odfmanifest_8py.html#aa30e4aac456f93d3a2ec1d6eafd77004", null ],
    [ "odfmanifest", "odfmanifest_8py.html#a69af946eb54c4a75e75cef5611d6fcef", null ],
    [ "MANIFESTNS", "odfmanifest_8py.html#a66286c05d5031965957b26b57b7bbfbd", null ],
    [ "result", "odfmanifest_8py.html#a1641ce31eefa41ae260f4bd5785b37b3", null ]
];