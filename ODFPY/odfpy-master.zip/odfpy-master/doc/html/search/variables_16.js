var searchData=
[
  ['xformsns',['XFORMSNS',['../namespaceodf_1_1namespaces.html#aab47b5215a420501e95ca654941c2676',1,'odf::namespaces']]],
  ['xhtmlns',['XHTMLNS',['../namespaceodf_1_1namespaces.html#a7b93ea22de258448c3a1a6953fa428b9',1,'odf::namespaces']]],
  ['xlinkns',['XLINKNS',['../namespaceodf_1_1namespaces.html#a8ba6bb05d0fd8d856ffdc2c7667aa5a3',1,'odf::namespaces']]],
  ['xmlfile',['xmlfile',['../classodf_1_1odf2xhtml_1_1ODF2XHTML.html#a7f4bf0df56081f422b31f78f6490d5af',1,'odf::odf2xhtml::ODF2XHTML']]],
  ['xmlns',['XMLNS',['../namespaceodf_1_1namespaces.html#aed440da8646f3c462c833fc283ccb23c',1,'odf::namespaces']]],
  ['xsdns',['XSDNS',['../namespaceodf_1_1namespaces.html#ae0a786c0d6f5f8398bab5b18c062512d',1,'odf::namespaces']]],
  ['xsins',['XSINS',['../namespaceodf_1_1namespaces.html#a46a3a0e49cc347678af5fb8d994652ce',1,'odf::namespaces']]]
];
