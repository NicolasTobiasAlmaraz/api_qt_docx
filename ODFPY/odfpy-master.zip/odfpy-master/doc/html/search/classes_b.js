var searchData=
[
  ['whitespacetext',['WhitespaceText',['../classodf_1_1teletype_1_1WhitespaceText.html',1,'odf::teletype']]]
];
