var searchData=
[
  ['year',['Year',['../namespaceodf_1_1number.html#a94719cca5c80ecae146f23f07e6fe205',1,'odf::number']]]
];
