var searchData=
[
  ['qname',['qname',['../classodf_1_1element_1_1Element.html#af094fd4f65c213f17b319c152f8be830',1,'odf::element::Element']]]
];
