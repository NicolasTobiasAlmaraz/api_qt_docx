var searchData=
[
  ['quarter',['Quarter',['../namespaceodf_1_1number.html#ae824690a033450862c823cf1c8312351',1,'odf::number']]]
];
