var searchData=
[
  ['namespaces_2epy',['namespaces.py',['../namespaces_8py.html',1,'']]],
  ['number_2epy',['number.py',['../number_8py.html',1,'']]]
];
