var classodf_1_1opendocument_1_1OpaqueObject =
[
    [ "__init__", "classodf_1_1opendocument_1_1OpaqueObject.html#a554252db63a883d6ff087f78a22ac880", null ],
    [ "content", "classodf_1_1opendocument_1_1OpaqueObject.html#ada08db06d347e302364e91f33926eb12", null ],
    [ "filename", "classodf_1_1opendocument_1_1OpaqueObject.html#af8f5a1a4e4daa535e72d304bfee40835", null ],
    [ "mediatype", "classodf_1_1opendocument_1_1OpaqueObject.html#a4bbb2cc311a0c74ce3f62b2681b79d56", null ]
];