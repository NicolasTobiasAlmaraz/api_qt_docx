var grammar_8py =
[
    [ "__doc__", "grammar_8py.html#acef64e7e05d460461ee25112dae95882", null ],
    [ "allowed_attributes", "grammar_8py.html#a977fc09293e3ad44040d3d0dd5d76e50", null ],
    [ "allowed_children", "grammar_8py.html#afedffb9bc285b6d478b821ee6f27db49", null ],
    [ "allows_text", "grammar_8py.html#af74bda0d0f630e9047b1d30972fb8892", null ],
    [ "required_attributes", "grammar_8py.html#a5a5da9502e3a9a572fe272da463f1877", null ]
];