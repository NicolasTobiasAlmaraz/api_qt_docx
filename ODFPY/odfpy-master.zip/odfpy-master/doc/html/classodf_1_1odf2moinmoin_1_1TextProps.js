var classodf_1_1odf2moinmoin_1_1TextProps =
[
    [ "__init__", "classodf_1_1odf2moinmoin_1_1TextProps.html#a1ade0318affae4dd50cc224e322844da", null ],
    [ "__str__", "classodf_1_1odf2moinmoin_1_1TextProps.html#a437f2858f4e8af5d57e153859172759c", null ],
    [ "setBold", "classodf_1_1odf2moinmoin_1_1TextProps.html#ab5b65c847ecb144c247ffcbda288a4ca", null ],
    [ "setFixed", "classodf_1_1odf2moinmoin_1_1TextProps.html#a36498ea16872e27d8279f02b0d2f6ce9", null ],
    [ "setItalic", "classodf_1_1odf2moinmoin_1_1TextProps.html#ae8595e3cbeb8353a5aba4599c0a0bed4", null ],
    [ "setPosition", "classodf_1_1odf2moinmoin_1_1TextProps.html#aafb89be476b19469697c8ea12abb421a", null ],
    [ "setStrikethrough", "classodf_1_1odf2moinmoin_1_1TextProps.html#a4400a7d550f519a6c3de5921f77aeab1", null ],
    [ "setUnderlined", "classodf_1_1odf2moinmoin_1_1TextProps.html#ac1f5eaeb017f7c0b18102c46a9b6fdc8", null ],
    [ "bold", "classodf_1_1odf2moinmoin_1_1TextProps.html#a587268cf70a69a9d233d782b141e576a", null ],
    [ "fixed", "classodf_1_1odf2moinmoin_1_1TextProps.html#af5b657bcbbbe1c12c0d6eb9d791fde6f", null ],
    [ "italic", "classodf_1_1odf2moinmoin_1_1TextProps.html#af85a0ebd5c214065777718be7a8df19a", null ],
    [ "strikethrough", "classodf_1_1odf2moinmoin_1_1TextProps.html#aa1880b520d5ce2db420658a2a1dd16e7", null ],
    [ "subscript", "classodf_1_1odf2moinmoin_1_1TextProps.html#a5c6f7ea5895085c1facc09c796eecbcc", null ],
    [ "superscript", "classodf_1_1odf2moinmoin_1_1TextProps.html#a36c85d769680a75b8fdc17c5f8a03a2a", null ],
    [ "underlined", "classodf_1_1odf2moinmoin_1_1TextProps.html#a6f12b62f5a4bb4a3e64d963858a628e9", null ]
];