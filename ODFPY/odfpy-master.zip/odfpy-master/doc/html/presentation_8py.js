var presentation_8py =
[
    [ "AnimationGroup", "presentation_8py.html#a5ab8f355021eafa308c0c61148fb97dc", null ],
    [ "Animations", "presentation_8py.html#a6e766c72aac1ec2e1204539a6209eb32", null ],
    [ "DateTime", "presentation_8py.html#a306ee731e45c82ea8196564fbf25b65d", null ],
    [ "DateTimeDecl", "presentation_8py.html#a2f5ab7601a332b6a726597faf6ce29ac", null ],
    [ "Dim", "presentation_8py.html#abec59f30e68813be509ff7958f40bc25", null ],
    [ "EventListener", "presentation_8py.html#a10a873f25e671d856844e6324d76b9c5", null ],
    [ "Footer", "presentation_8py.html#a34dc6d4fae71a268b8ae1c6c93a1604a", null ],
    [ "FooterDecl", "presentation_8py.html#ad64dd8b08b5c28815d567a8b5442a0a0", null ],
    [ "Header", "presentation_8py.html#a570922e6a160afbe90db899357860e99", null ],
    [ "HeaderDecl", "presentation_8py.html#aa96209c8fdb02a4bedcb19ef5733981e", null ],
    [ "HideShape", "presentation_8py.html#a79c781696d5dc84d5b59bdd29ab06e29", null ],
    [ "HideText", "presentation_8py.html#af9f43b5a546d5119f82f99ceec07b8a9", null ],
    [ "Notes", "presentation_8py.html#a5c91562888ed717a8b6825e539282da9", null ],
    [ "Placeholder", "presentation_8py.html#a42f23ec52c296e37bf900a175e21a04e", null ],
    [ "Play", "presentation_8py.html#ab876940af857190232d52ff52d89e264", null ],
    [ "Settings", "presentation_8py.html#a836fd56e29a989ac1dda296d98b778ac", null ],
    [ "Show", "presentation_8py.html#aff0d1cca8afce3c781cea2ef79fc75f3", null ],
    [ "ShowShape", "presentation_8py.html#ac6736ad6f28cb36f3e12ff3c51be0642", null ],
    [ "ShowText", "presentation_8py.html#a41615024b8d3c8eb98c43826119947bb", null ],
    [ "Sound", "presentation_8py.html#af28e479add5eb61bbad77130a6f64462", null ]
];