var classodf_1_1element_1_1CDATASection =
[
    [ "toXml", "classodf_1_1element_1_1CDATASection.html#a76be678b6581cf1b8b5016100bf468d9", null ],
    [ "nodeType", "classodf_1_1element_1_1CDATASection.html#a77185faced1c6e282b1456892a7ac36d", null ]
];